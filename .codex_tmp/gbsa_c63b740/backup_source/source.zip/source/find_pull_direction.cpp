#include"MOL.h"
#include"functions.h"
#include<random>
#include<cmath>
#include<iomanip>
#include<thread>
#include"differential_evolution.h"
const double PI = 3.14159265;

bool restrain_dis_ligand_pathway(groups_cal& groups, Multi_MOL& rec, MOL& lg_candidate, arguments& Arguments)
{
	if (Arguments.flag_pathway == false)
		return true;
	double com_lg_candidate[3]{};
	lg_candidate.get_centroid(com_lg_candidate);

	bool flag_dis_min{ false };

	for (size_t i{}; i < groups.groups_atom_number(groups.group_pathway_index()); ++i)
	{
		if (rec.info[groups.atom_index(groups.group_pathway_index(), i) - 1].get_atom_type().substr(0, 1) != "H")
		{
			if (rec.m_mol[0].dis_between_atom_and_point(groups.atom_index(groups.group_pathway_index(), i) - 1, com_lg_candidate[0], com_lg_candidate[1], com_lg_candidate[2]) < Arguments.dis_along_path)
			{
				flag_dis_min = true;
				break;
			}
		}
	}
	return flag_dis_min;
}

double cal_min_dis_ligand_pathway(groups_cal& groups, Multi_MOL& rec, MOL& lg_candidate, arguments& Arguments)
{
	if (Arguments.flag_pathway == false)
		return true;
	double com_lg_candidate[3]{};
	lg_candidate.get_centroid(com_lg_candidate);

	double mindis{ 10000. };

	for (size_t i{}; i < groups.groups_atom_number(groups.group_pathway_index()); ++i)
	{
		if (rec.info[groups.atom_index(groups.group_pathway_index(), i) - 1].get_atom_type().substr(0, 1) != "H")
		{
			double dis{ rec.m_mol[0].dis_between_atom_and_point(groups.atom_index(groups.group_pathway_index(), i) - 1, com_lg_candidate[0], com_lg_candidate[1], com_lg_candidate[2]) };
			if (dis < mindis)
			{
				mindis = dis;
			}
		}
	}
	return mindis;
}

double cal_score_function(cache_energy& energy_trial, cache_energy& energy_ref, int flag_function)
{
	if (flag_function == 1)
	{
		return energy_trial.elec_ener + energy_trial.vdw_ener - energy_ref.elec_ener - energy_ref.vdw_ener +
			2.*fabs(energy_trial.elec_ener + energy_trial.vdw_ener);
	}
	else
	{
		return -1.*exp(1.6863*(-energy_trial.elec_ener-energy_trial.vdw_ener+energy_ref.elec_ener+energy_ref.vdw_ener));
	}
}

bool check_radius(de_arg& DE_arguments, force& tran_vector)
{
	return(tran_vector.modul() < DE_arguments.scan_radius && tran_vector.modul() > DE_arguments.min_scan_radius);
}

bool parse_angle(de_arg& DE_arguments, force& tran_vector, double& crit_angle)
{	
	
	if (DE_arguments.flag_old_vec == true)
	{
		//angle(u,v)=2arctan(||v|u-|u|v|,||v|u+|u|v|)

		double ddX{ tran_vector.Fz * sin(tran_vector.Fx) * cos(tran_vector.Fy) },
			ddY{ tran_vector.Fz * sin(tran_vector.Fx) * sin(tran_vector.Fy) },
			ddZ{ tran_vector.Fz * cos(tran_vector.Fx) };
		double modul1{ tran_vector.Fz }, modul2{ DE_arguments.old_vector.modul() };
		force v1{ ddX,ddY,ddZ }, v2{ DE_arguments.old_vector }; v1 *= modul2; v2 *= modul1;

		//crit_angle = 180. / PI * acos((-DE_arguments.old_vector.Fx*ddX - DE_arguments.old_vector.Fy*ddY - DE_arguments.old_vector.Fz*ddZ)
		//	/ (DE_arguments.old_vector.modul()*fabs(tran_vector.Fz)));
		crit_angle = fabs(360.* atan2(force(v1 - v2).modul(), force(v1 + v2).modul())/PI);
	}
	else
		crit_angle = DE_arguments.restrain_angle - 1.;

	if (crit_angle >= DE_arguments.restrain_angle)
		return false;
	else
		return true;
}

int parse_new_mol(MOL& mol_temp, double dX, double dY, double dZ, arguments& Arguments,Multi_MOL& rec, Multi_MOL& lg_seed,
	cache_sigma_epsilon& CachedData, cache_energy& e_cache)
{
	mol_temp.translate(dX, dY, dZ);
	if (Arguments.force_f.find("CHARMM") != string::npos || Arguments.force_f.find("AMBER") != string::npos || Arguments.force_f.find("OPLSAA") != string::npos)
	{
		cal_energy_amber(rec.m_mol[0], mol_temp, rec.info, lg_seed.info, CachedData, 0, mol_temp.Molecule.size(), e_cache, 0, Arguments,
			rec.parameters, lg_seed.parameters);
	}
	else
	{
		cal_energy_gromos(rec.m_mol[0], mol_temp, rec.info, lg_seed.info, CachedData, 0, mol_temp.Molecule.size(), e_cache, 0, Arguments,
			rec.parameters, lg_seed.parameters);
	}
	return 0;
}

int Multi_MOL::gen_pop(MOL& mol_seed, de_arg& DE_arguments, vector<mol_info>& info, string mol_type, vector<force>& tran_data)
{
	std::random_device rd;
	std::mt19937 mt(rd());
	std::uniform_real_distribution<double> dist_phi(0, 2.*PI), dist_theta(0, PI), dist_rho(0.9*DE_arguments.scan_radius, DE_arguments.scan_radius);

	this->m_mol.reserve(DE_arguments.pop_num);

	for (size_t i{}; i < DE_arguments.pop_num; ++i)
	{
		double phi{ dist_phi(mt) }, theta{ dist_theta(mt) }, rho{dist_rho(mt)};
		double dX{ rho*sin(theta)*cos(phi) },
			dY{ rho*sin(theta)*sin(phi) },
			dZ{ rho*cos(theta) };

		if (DE_arguments.flag_old_vec == true)
		{
			force tran_vector(theta, phi, rho);
			double modul1{ tran_vector.Fz }, modul2{ DE_arguments.old_vector.modul() };
			force v1{ dX,dY,dZ }, v2{ DE_arguments.old_vector }; v1 *= modul2; v2 *= modul1;

			//crit_angle = 180. / PI * acos((-DE_arguments.old_vector.Fx*ddX - DE_arguments.old_vector.Fy*ddY - DE_arguments.old_vector.Fz*ddZ)
			//	/ (DE_arguments.old_vector.modul()*fabs(tran_vector.Fz)));
			double angle{ fabs(360. * atan2(force(v1 - v2).modul(), force(v1 + v2).modul()) / PI) };
			if (angle >= DE_arguments.restrain_angle)
			{
				--i; continue;
			}
		}

		tran_data.emplace_back(theta, phi, rho);

		for (size_t j{}; j < mol_seed.Molecule.size(); ++j)
		{
			emplace(i, mol_seed.Box, mol_seed.get_time(), mol_seed.get_force_f(), info[j],
				molecule(mol_seed.Molecule[j].get_x() + dX, mol_seed.Molecule[j].get_y() + dY, mol_seed.Molecule[j].get_z() + dZ), mol_type);
		}
	}
	return 0;
}

int cal_energy_part_DE(Multi_MOL& rec, Multi_MOL& lg_seed, Multi_MOL& lg_candidates, cache_sigma_epsilon& CachedData, de_arg& DE_arguments,
	vector<cache_energy>& Energies, arguments& Arguments, size_t begin, size_t end)
{
	if (Arguments.force_f.find("CHARMM") != string::npos || Arguments.force_f.find("AMBER") != string::npos || Arguments.force_f.find("OPLSAA") != string::npos)
	{
		for (size_t i{ begin }; i < end; ++i)
		{
			cal_energy_amber(rec.m_mol[0], lg_candidates.m_mol[i], rec.info, lg_seed.info, CachedData, 0, lg_seed.m_mol[0].Molecule.size(),
				Energies[i], i, Arguments, rec.parameters, lg_seed.parameters);
		}
	}
	else
	{
		for (size_t i{ begin }; i < end; ++i)
			cal_energy_gromos(rec.m_mol[0], lg_candidates.m_mol[i], rec.info, lg_seed.info, CachedData, 0, lg_seed.m_mol[0].Molecule.size(),
				Energies[i], i, Arguments, rec.parameters, lg_seed.parameters);
	}
	return 0;
}

int impl_evo_1_ite(Multi_MOL& rec, Multi_MOL& lg_seed, Multi_MOL& lg_candidates, cache_sigma_epsilon& CachedData, de_arg& DE_arguments,
	vector<cache_energy>& Energies, arguments& Arguments, size_t begin, size_t end, const vector<force>& tran_data, vector<force>& out_tran, size_t thread_rank
,cache_energy& energy_ref, groups_cal& Groups_from_index_file, int flag_score_function)
{
	std::random_device rd;
	std::mt19937 mt(rd());
	std::uniform_int_distribution<size_t> dist_choose(0, DE_arguments.pop_num - 1);
	std::uniform_real_distribution<double>  dist_gencrit(0., 1.);


	for (size_t i{ begin }; i < end; ++i)
	{
		size_t abc_pop[3]{};
		size_t temp_1{ (dist_choose(mt) + thread_rank) % DE_arguments.pop_num }, temp_2{ dist_choose(mt) }, temp_3{ dist_choose(mt) };

		while (temp_1>= DE_arguments.pop_num || temp_1 == temp_2 || temp_1 == temp_3 || temp_2 == temp_3 || temp_1 == i || temp_2 == i || temp_3 == i)
		{
			temp_1 = dist_choose(mt);
			temp_2 = dist_choose(mt);
			temp_3 = dist_choose(mt);
		}
		abc_pop[0] = temp_1; abc_pop[1] = temp_2; abc_pop[2] = temp_3;
		size_t random_index{ dist_choose(mt) };
		double crit{ dist_gencrit(mt) };
		force tran_vector;
		MOL mol_temp{ lg_candidates.m_mol[i] };
		cache_energy e_cache;
		double crit_angle{ 180. };

		if (DE_arguments.algorithm == 0)
		{
			if (crit < DE_arguments.cross_prob || i == random_index)
			{
				tran_vector.Fx = tran_data[abc_pop[0]].Fx + DE_arguments.diff_weight*(tran_data[abc_pop[1]].Fx - tran_data[abc_pop[2]].Fx);
				tran_vector.Fy = tran_data[abc_pop[0]].Fy + DE_arguments.diff_weight*(tran_data[abc_pop[1]].Fy - tran_data[abc_pop[2]].Fy);
				tran_vector.Fz = tran_data[abc_pop[0]].Fz + DE_arguments.diff_weight*(tran_data[abc_pop[1]].Fz - tran_data[abc_pop[2]].Fz);
			}
			tran_vector.Fz = fabs(tran_vector.Fz);

			if (false == parse_angle(DE_arguments, tran_vector, crit_angle) && false==check_radius(DE_arguments,tran_vector))
				continue;

			double dX{ tran_vector.Fz*sin(tran_vector.Fx)*cos(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*cos(tran_data[i].Fy) },
				dY{ tran_vector.Fz*sin(tran_vector.Fx)*sin(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*sin(tran_data[i].Fy)},
				dZ{ tran_vector.Fz*cos(tran_vector.Fx) - tran_data[i].Fz*cos(tran_data[i].Fx)};

			parse_new_mol(mol_temp, dX, dY, dZ, Arguments, rec, lg_seed, CachedData, e_cache);
		}
		else
		{
			if (crit < DE_arguments.cross_prob)
			{
				tran_vector.Fx = tran_data[abc_pop[0]].Fx + DE_arguments.F*(tran_data[abc_pop[1]].Fx - tran_data[abc_pop[2]].Fx);
				tran_vector.Fy = tran_data[abc_pop[0]].Fy + DE_arguments.F*(tran_data[abc_pop[1]].Fy - tran_data[abc_pop[2]].Fy);
				tran_vector.Fz = tran_data[abc_pop[0]].Fz + DE_arguments.F*(tran_data[abc_pop[1]].Fz - tran_data[abc_pop[2]].Fz);
				tran_vector.Fz = fabs(tran_vector.Fz);

				double dX{ tran_vector.Fz*sin(tran_vector.Fx)*cos(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*cos(tran_data[i].Fy) },
					dY{ tran_vector.Fz*sin(tran_vector.Fx)*sin(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*sin(tran_data[i].Fy) },
					dZ{ tran_vector.Fz*cos(tran_vector.Fx) - tran_data[i].Fz*cos(tran_data[i].Fx) };

				if (false == parse_angle(DE_arguments, tran_vector, crit_angle) && false == check_radius(DE_arguments, tran_vector))
					continue;

				parse_new_mol(mol_temp, dX, dY, dZ, Arguments, rec, lg_seed, CachedData, e_cache);
			}
			else
			{
				tran_vector.Fx = tran_data[abc_pop[0]].Fx + 0.5*(DE_arguments.F + 1.)*(tran_data[abc_pop[1]].Fx + tran_data[abc_pop[2]].Fx - 2.*tran_data[abc_pop[0]].Fx);
				tran_vector.Fy = tran_data[abc_pop[0]].Fy + 0.5*(DE_arguments.F + 1.)*(tran_data[abc_pop[1]].Fy + tran_data[abc_pop[2]].Fy - 2.*tran_data[abc_pop[0]].Fy);
				tran_vector.Fz = tran_data[abc_pop[0]].Fz + 0.5*(DE_arguments.F + 1.)*(tran_data[abc_pop[1]].Fz + tran_data[abc_pop[2]].Fz - 2.*tran_data[abc_pop[0]].Fz);
				tran_vector.Fz = fabs(tran_vector.Fz);

				double dX{ tran_vector.Fz*sin(tran_vector.Fx)*cos(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*cos(tran_data[i].Fy) },
					dY{ tran_vector.Fz*sin(tran_vector.Fx)*sin(tran_vector.Fy) - tran_data[i].Fz*sin(tran_data[i].Fx)*sin(tran_data[i].Fy) },
					dZ{ tran_vector.Fz*cos(tran_vector.Fx) - tran_data[i].Fz*cos(tran_data[i].Fx) };

				if (false == parse_angle(DE_arguments, tran_vector, crit_angle) && false == check_radius(DE_arguments, tran_vector))
					continue;

				parse_new_mol(mol_temp, dX, dY, dZ, Arguments, rec, lg_seed, CachedData, e_cache);
			}
		}

		double dis_candidate{ cal_min_dis_ligand_pathway(Groups_from_index_file, rec, mol_temp, Arguments) },
			dis_old_mem{ cal_min_dis_ligand_pathway(Groups_from_index_file,rec,lg_candidates.m_mol[i],Arguments) };

		if (parse_angle(DE_arguments, tran_vector, crit_angle) &&  check_radius(DE_arguments, tran_vector)
			&& (restrain_dis_ligand_pathway(Groups_from_index_file,rec,mol_temp,Arguments)|| dis_candidate<=dis_old_mem)
			&& (cal_score_function(e_cache,energy_ref,flag_score_function) < cal_score_function(Energies[i],energy_ref,flag_score_function)))
		{
			out_tran[i] = tran_vector;
			Energies[i] = e_cache;
			lg_candidates.m_mol[i] = mol_temp;
		}
	}

	return 0;
}

int evo_1_ite(Multi_MOL& rec, Multi_MOL& lg_seed, Multi_MOL& lg_candidates, cache_sigma_epsilon& CachedData, de_arg& DE_arguments,
	vector<cache_energy>& Energies, arguments& Arguments, vector<force>& tran_data
	, cache_energy& energy_ref, groups_cal& Groups_from_index_file)
{
	vector<force> out_tran(tran_data);
	vector<thread> threads(Arguments.nt);
	for (size_t i{}; i < threads.size(); ++i)
		threads[i] = thread(impl_evo_1_ite, ref(rec), ref(lg_seed), ref(lg_candidates), ref(CachedData), ref(DE_arguments), ref(Energies), ref(Arguments), i*lg_candidates.m_mol.size() / threads.size()
			, (i + 1)*lg_candidates.m_mol.size() / threads.size(), ref(tran_data), ref(out_tran), i + 1, ref(energy_ref), ref(Groups_from_index_file), Arguments.de_flag_score_function);
	for (auto& t : threads)
		t.join();
	tran_data = out_tran;
	return 0;
}

int find_pull_direct(Multi_MOL& rec, Multi_MOL& lg, cache_sigma_epsilon& CachedData, de_arg& DE_arguments, arguments& Arguments
	, info& output_info, groups_cal& Groups_from_index_file)
{
	if (rec.m_mol[0].mindist_mol(lg.m_mol[0], Arguments, DE_arguments) == true)
	{
		cout << "Automatic termination is on!\n";
		return 1;
	}

	cache_energy energy_ref;
	vector<thread> threads(Arguments.nt);

	if (Arguments.force_f.find("CHARMM") != string::npos || Arguments.force_f.find("AMBER") != string::npos || Arguments.force_f.find("OPLSAA") != string::npos)
	{
		for (size_t i{}; i < threads.size(); ++i)
			threads[i] = thread(cal_energy_amber,ref(rec.m_mol[0]), ref(lg.m_mol[0]), ref(rec.info), ref(lg.info), ref(CachedData)
				, i* lg.m_mol[0].Molecule.size()/threads.size(), (i+1)*lg.m_mol[0].Molecule.size()/threads.size(), ref(energy_ref), 0, ref(Arguments),
			ref(rec.parameters), ref(lg.parameters));
		for (auto& t : threads)t.join();
	}

	Multi_MOL lg_candidates;
	lg_candidates.m_mol.reserve(DE_arguments.pop_num);

	vector<force> tran_data;

	cout << "Generating population......";
	lg_candidates.gen_pop(lg.m_mol[0], DE_arguments, lg.info, lg.mol_type, tran_data);
	cout << "done!\n";

	vector<cache_energy> Energies(DE_arguments.pop_num);
	for (size_t i{}; i < threads.size(); ++i)
		threads[i] = thread(cal_energy_part_DE, ref(rec), ref(lg), ref(lg_candidates), ref(CachedData), ref(DE_arguments), ref(Energies), ref(Arguments),
			i*lg_candidates.m_mol.size() / threads.size(), (i + 1)*lg_candidates.m_mol.size() / threads.size());
	for (auto& t : threads)t.join();

	cout << "Evolution stage........";
	for (size_t i{}; i < DE_arguments.ite_num; ++i)
	{
		cout << "  " << i + 1;
		evo_1_ite(rec, lg, lg_candidates, CachedData, DE_arguments, Energies, Arguments, tran_data, energy_ref, Groups_from_index_file);
	}
	cout << '\n';

	fstream de_output(output_info.get_DE_output_filename(), ios::out), de_log(output_info.get_DE_log_filename(),ios::out|ios::app), de_pdb_out(output_info.get_DE_pdb_vector_filename(), ios::out | ios::app);
	fstream enery("out_energy_pop.dat", ios::out), best_conf("best_conf.pdb", ios::out);

	double min_e{ cal_score_function(Energies[0],energy_ref,Arguments.de_flag_score_function) };
	size_t pos{};
	for (size_t i{ 1 }; i < Energies.size(); ++i)
	{
		enery << i << ": " << Energies[i].elec_ener << "  " << Energies[i].vdw_ener << "  " << energy_ref.elec_ener << "  " << energy_ref.vdw_ener ;
		
		double dX{ tran_data[i].Fz*sin(tran_data[i].Fx)*cos(tran_data[i].Fy) },
			dY{ tran_data[i].Fz*sin(tran_data[i].Fx)*sin(tran_data[i].Fy) },
			dZ{ tran_data[i].Fz*cos(tran_data[i].Fx) };
		double modul_old{ DE_arguments.old_vector.modul() }, modul_new{ tran_data[pos].Fz };
		force new_vec{ dX,dY,dZ }, old_vec{ DE_arguments.old_vector }; new_vec *= modul_old; old_vec *= modul_new;
		enery<<"  "<< 360. / PI * atan2(force(new_vec - old_vec).modul(), force(new_vec + old_vec).modul()) <<'\n';

		if (cal_score_function(Energies[i],energy_ref, Arguments.de_flag_score_function)  < min_e)
		{
			pos = i;
			min_e = cal_score_function(Energies[i], energy_ref, Arguments.de_flag_score_function);
		}
	}

	enery << "MIN ENERGY: " << min_e << ": elec: " << Energies[pos].elec_ener << "  vdw: " << Energies[pos].vdw_ener << '\n';

	double dX{ tran_data[pos].Fz*sin(tran_data[pos].Fx)*cos(tran_data[pos].Fy) },
		dY{ tran_data[pos].Fz*sin(tran_data[pos].Fx)*sin(tran_data[pos].Fy) },
		dZ{ tran_data[pos].Fz*cos(tran_data[pos].Fx) };
	double modul_old{ DE_arguments.old_vector.modul() }, modul_new{ tran_data[pos].Fz };
	force new_vec{ dX,dY,dZ }, old_vec{ DE_arguments.old_vector }; new_vec *= modul_old; old_vec *= modul_new;

	de_output << dX << "  " << dY << "  " << dZ << "  Angle: "
		<< 360. / PI * atan2(force(new_vec - old_vec).modul(), force(new_vec + old_vec).modul())
		<< " -- Modul: " << new_vec.modul() << " Angstrom\n";
	de_log << dX << "  " << dY << "  " << dZ << "  Angle: "
		<< 360. / PI * atan2(force(new_vec - old_vec).modul(), force(new_vec + old_vec).modul())
		<< " -- Modul: " << new_vec.modul() << " Angstrom\n--------------------------\n";
	double x{}, y{}, z{}, mass{};
	size_t atom{};
	for (auto& a : lg.m_mol[0].Molecule)
	{
		x += a.get_x()*lg.parameters[atom].get_mass();
		y += a.get_y()*lg.parameters[atom].get_mass();
		z += a.get_z()*lg.parameters[atom].get_mass();
		mass += lg.parameters[atom].get_mass();
		++atom;
	}
	x /= mass; y /= mass; z /= mass;
	best_conf.precision(3);
	for (size_t i{}; i < lg_candidates.m_mol[pos].Molecule.size(); ++i)
		best_conf << "ATOM" << setw(7) << i + 1 << setw(5) << lg.info[i].get_atom() << setw(4) << lg.info[i].get_original_res_name() << " A" << setw(4) << 1
		<< setw(12) << fixed << lg_candidates.m_mol[pos].Molecule[i].get_x() << setw(8) << fixed << lg_candidates.m_mol[pos].Molecule[i].get_y()
		<< setw(8) << fixed << lg_candidates.m_mol[pos].Molecule[i].get_z() << setw(7) << 1.00 << setw(6) << 0.00 << '\n';

	de_pdb_out.precision(3);
	de_pdb_out<<"ATOM"<<setw(7)<<1<<setw(5)<<"CA"<<setw(4)<<"ALA"<<" A"<<setw(4)<<1<<setw(12)<<fixed<<x<<setw(8) << fixed<<y<<setw(8)<<fixed<<z
		<< " " << setw(7) << 1.00 << " " << setw(6) << 0.00 << '\n';
	de_pdb_out<<"ATOM"<<setw(7)<<2<<setw(5)<<"CB"<<setw(4)<<"ALA"<<" A"<<setw(4)<<1<<setw(12)<<fixed<< x+dX<<setw(8)<<fixed<<y+dY<<setw(8)<<fixed<<z+dZ
		<< " " << setw(7) << 1.00 << " " << setw(6) << 0.00 << '\n';
	de_pdb_out << "TER\n";
	return 0;
}